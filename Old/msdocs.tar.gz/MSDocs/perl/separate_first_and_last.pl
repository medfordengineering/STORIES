while (my $line = <>){
	chomp($line);
	my @fields = split /\s+/, $line;
	print $fields[0], ",", $fields[1], "\n";
}
