my $count;
while (my $line = <>){
	chomp($line);
	my @fields = split /\s+/, $line;
	print $fields[4], ",";
	$count += 1;
	if ($count == 50){
		print "\n \n";
		$count = 0;
		}
	}
