while (my $line = <>){
	chomp($line);
	my @fields = split /,/, $line;
	print $fields[4], ",", "\n";
}
